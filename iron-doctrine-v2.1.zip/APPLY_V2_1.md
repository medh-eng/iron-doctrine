# Apply design v2.1 (fits design v2 onto the existing v0.2.3 game)

This pack changes design docs, tools and data files only. **No game code in `src/js/` changes**, and the game plays exactly as before.

## Steps

1. **Unzip** this pack into the repository root, overwriting the files it contains. Then delete the zip.
2. **Delete** these files. The pack replaces them.
   - `UPDATE_NOTES.md`
   - `src/parts/weapon/wpn_c75_std.json` and `src/parts/weapon/wpn_c75_std.svg` (now `c75.json` and `c75.svg`)
   - `src/vehicles/test_gun_block.json` (replaced by the 15 v1 templates)
3. **Check:**
   - `node tools/check-parts.mjs`: expect 52 parts, 15 materials, 15 vehicles, no format errors.
   - `node tools/verify-bridge.mjs`: expect "differences: 0" and "template differences: 0".
   - `node build.mjs`, then `npm test`: all viewports pass.
4. **Commit:** "Design v2.1: part library uses the game's ids; v1 parts and templates imported". Add a Progress log row in `design/06` (version stays 0.2.3; docs and data only).
5. **Delete this file** (`APPLY_V2_1.md`) in the same commit.
6. **Continue with step 2.5a** in `design/06`, unless the producer says otherwise.

## What changed and why (for the summary)

- **The part library now uses the game's own ids, categories and stat names.** It holds all 52 v1 parts (`src/parts/<category>/<id>.json`), the 7 v1 structure cells (`materials.json`) and the 15 v1 templates (`src/vehicles/`), copied exactly from `07_data.js`.
- **SVG art is optional.** Parts without it keep the v1 code drawing.
- **Design v2 now builds on v1.** Submarines stay (any sea class that can dive). Aircraft and helicopters become carrier- and airfield-launched air wings in campaigns (Part 5); until then they fight as they do now. Airships are added in step 2.7, using the helicopter controls.
- **v1 docs are archived** in `design/v1/`, because code comments still point to them.
- **The roadmap now continues from v0.2.3:**
  - 2.5: parts from the library, SVG art
  - 2.6: three on the field, the command wheel, the Battle Simulator
  - 2.7: airships
  - 2.8: classes, tiers and paint
  - then the campaign (Part 3 onwards)
