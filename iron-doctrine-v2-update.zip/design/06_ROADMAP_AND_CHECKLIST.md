# Iron Doctrine: roadmap and release checklist (v2)

- **Releases:** each part is a playable release on the GitHub Pages link. Part N is version 0.N.x.
- **Sessions:** a part may span several sessions (sub-steps a, b, c).
- **Progress log:** each session ends with a row in the table at the bottom.
- **v2 note:** Part 1a (engine core) is the same as in v1. Keep whatever is already built. From 1b onwards the plan follows the v2 design (01).

## Part 1: Battle core (v0.1)

### 1a. Engine core (unchanged from v1)

- boot, landscape layout, rotate card
- input router and transparent thumb controls
- audio engine, first sound effects, title music
- Settings, Pause, saves
- title screen skeleton
- extend the test harness (the starter repo already has the build, test build, smoke test and screenshots)
- optional: web app manifest and icons, so the home-screen app opens full screen and sideways

### 1b. Battle core: land and air

- `05b_partrender.js`: port `tools/part-render.js`, with SVG paint tokens, auto-tiled structure and moving groups (07 §6). Composed ships are cached as sprites.
- Designs load from `PART_LIBRARY.vehicles`. Use the batch F starting designs as soon as they exist; until then use simple placeholder designs built from materials plus `wpn_c75_std`.
- **Physics:**
  - land: terrain heightfield, wheels and tracks, ground pressure, slopes, tipping, bogging
  - air: lift margin, thrust, climb and descend, falling when envelopes are lost
- **Combat:**
  - projectiles, penetration and angle, per-part damage, fire, debris, spotting
  - damage types: kinetic and HE for now
- **Three on the field and reserves:**
  - line-up, pull back, entry from the rear edge
  - destroyed ships replaced
  - win and lose checks
- **Control:** drive one ship and swap. The command wheel gives Move to, Fire at, Hold, Pull back, Smoke. The reserve drawer.
- **Enemy AI:** captain skill by level; uses its own reserve rotation.
- **Feel:** effects and floating text; battle music with intensity layers; tactical Start/Stop time.

### 1c. Sea, Drafting Office v1, Battle Simulator

- **Sea physics:** buoyancy per hull cell, waves, flooding and bulkheads. Coastal battlefields mix land, sea and air.
- **Drafting Office v1** (ship tab):
  - domain and class selector with grid and part limits
  - palette of tier 0–1 parts and materials
  - templates (the batch F designs), scratch build
  - stats drawer (numbers only), marks and change log
  - paint (schemes, custom colours, camouflage)
- **Battle Simulator:** pick your designs, a battlefield and an enemy force by tier; fight straight away.
- **Title screen:** AI-vs-AI demo battle behind it.

### Acceptance (Part 1)

- [ ] Both thumbs work at once. FIRE tap auto-aims; press-and-drag aims manually. Swap, Group and Utility work. The command wheel orders work.
- [ ] Tap, drag and pinch on the world never steal a touch from the controls.
- [ ] Three-on-field works on both sides: pull back → the next ship arrives from the rear; destroyed ships are replaced; line-up order is respected.
- [ ] Damage is visible and physical: parts detach, a lost engine immobilises, a lost gun goes silent, lost envelopes make an airship fall, flooding sinks a ship.
- [ ] These emerge from the numbers without special-case code:
  - top-heavy designs tip
  - underpowered designs stall on hills
  - tracks beat wheels in mud
  - overloaded airships sink
- [ ] Ships look like 07 describes: part art, auto-tiled hull and paint schemes render correctly at phone scale.
- [ ] Designer: class limits are enforced and invalid placements explained. Saving makes the next mark.
- [ ] Audio: every Part 1 action has a distinct sound; Music, Sound and Vibration toggles are remembered.
- [ ] Smooth on a phone, no console errors, release checklist passed.

## Part 2: World map and fleets (v0.2)

- **World generation** (seeded):
  - terrain, biomes, roads, ruins and scrap fields, sea
  - weather that drifts
  - faction territories (09 layout)
  - settlements of all 5 types, each faction's capital, neutral villages
- **Map rendering:**
  - pre-rendered chunks and the tactical overlay
  - pan and zoom
  - fog of war, detection
- **Clock:** Start/Stop, 1×/3×/10×, auto-stop events.
- **Officers and fleets** (14b):
  - the Grand Admiral, admirals, captains
  - fleets per domain, fleet-size and class limits by level
  - moving by domain rules, path preview with fuel
  - stranding
- **Faction choice** at New campaign; the starting set-up from 01 §4.3.
- **Settlements (basic):** dock, buy and sell fuel and ammo at markets, the treasury.
- **Contact → pre-battle card → battle or auto-resolve → results back on the map.**
- **Persistence:** ship damage, losses and XP, captain survival; saves and loads.

### Acceptance (Part 2)

- [ ] A new campaign in any faction starts with the correct home territory and 3 fleets.
- [ ] Fleets move by domain rules; fuel burns; an empty fleet is stranded; path previews warn before it happens.
- [ ] Buying fuel and ammo uses the global treasury from any docked fleet.
- [ ] Battles start from map contact. Only allowed domains deploy. Results persist.
- [ ] Removing a captain garrisons them where they're left. Captains can't move alone.

## Part 3: Economy, logistics and sieges (v0.3)

- **Warehouses and holds:**
  - physical cargo for every resource except money
  - transfers between fleets and settlements
  - capacity limits
- **Production** by settlement type and biome; upkeep and wages; running dry (01 §8.5).
- **Markets** for all goods, with stock and prices (08 §6).
- **Workshop:** crafting queue; refinery (scrap → electronics).
- **Yard:** build ships from designs; refit and swap; dock repair; field repair and the mobile workshop.
- **Salvage and reverse-engineering;** scrap fields.
- **Recruitment:** captains with ships, admirals, quartermasters, promotion.
- **Convoys:** quartermasters, standing supply routes, the logistics view, raiding.
- **Settlement upgrades** (village → city or fort → …).
- **Sieges:** walls, emplacement slots (install parts), keep, garrison rotation, capture, plunder.

### Acceptance (Part 3)

- [ ] A campaign cannot be sustained on salvage alone. Supply routes visibly keep a fleet going.
- [ ] Crafting only works with the materials physically at that settlement or in the docked hold.
- [ ] A convoy on a standing route runs by itself, can be intercepted, and its loss is felt at the other end.
- [ ] Sieges work from both sides. A captured settlement changes owner and restarts production after 2 days.

## Part 4: Research and advanced warfare (v0.4)

- **Tech tree and perks:** Command Points, research at cities and metropolises (08 §11–12).
- **Grand Admiral ranks;** admiral and captain levelling fully applied.
- **Drafting Office:** Missile tab (missile designer) and Drone tab (drone designer, grid limit set by the drone computer).
- **Missiles:** racks, VLS, magazines; guidance vs flares and ECM; warheads HE, napalm, acid, EMP, cluster.
- **Carriers and drones:** hangars, drone computers, drone orders; drones lost when their carrier leaves or dies.
- **Fabricators;** release clamps and detachable sections.
- **Flamethrowers, lasers, plasma;** power and heat management; damage types and material resistances.
- **Radar, ECM, stabilisers;** the tier 3–4 music layer.

### Acceptance (Part 4)

- [ ] Researching a node unlocks its parts for crafting and the designer. Command Points force real choices.
- [ ] A drone carrier built in the designer launches drones that follow orders, and loses them when it retreats.
- [ ] Every warhead type has a visible, distinct effect. Flares beat heat seekers more than radar seekers.
- [ ] Energy weapons are limited by power and heat, not ammo.

## Part 5: Living world and polish (v0.5 → 1.0)

- **Faction strategic AI:** expand, run convoys, raid, besiege, defend capitals; personalities per 09.
- **AI designs evolve** to counter what the player fields most (the no-meta pillar).
- **Relations:** war and truce changes, reputation, charters for neutral villages.
- **Win and lose conditions,** the war journal, medals, the blueprint gallery.
- **Optional:** the Gauntlet mode.
- **Balance pass** with simulator telemetry (08); performance pass on a mid-range Android phone.
- **Accessibility pass:** text size, colour-blind-safe status icons, reduced motion.

## Ongoing: art integration

- Foundry zips arrive in any order (10_PART_ROSTER). Integrate them as CLAUDE.md describes, whenever they appear in the repo root.
- **Code must never hard-code a part's look.** Everything comes from `PART_LIBRARY`.
- **Placeholders:** until a part's art exists, the designer shows a labelled grey block with the part's footprint. The part is usable in code as soon as its JSON exists.

## Release checklist (every part)

- [ ] `node build.mjs` passes (part library, syntax, no test code, no external URLs).
- [ ] `npm test` passes at all 5 viewports with no console errors. Screenshots reviewed.
- [ ] Scripted play covers the new systems (04 §10).
- [ ] Tested on a real Android phone in Chrome: landscape, both thumbs, pinch, background → auto-pause.
- [ ] Old saves migrate or are backed up with a message.
- [ ] `GAME_VERSION` bumped; `docs/index.html` rebuilt and committed.
- [ ] Progress log row added below.

## Progress log

| Date | Part | Version | What changed | Notes / next |
|---|---|---|---|---|
| | | | | |
